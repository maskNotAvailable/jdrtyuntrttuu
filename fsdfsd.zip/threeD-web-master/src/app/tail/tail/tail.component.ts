import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tail',
  templateUrl: './tail.component.html',
  styleUrls: ['./tail.component.css']
})
export class TailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
