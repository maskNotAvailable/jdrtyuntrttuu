import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialog-task-blank',
  templateUrl: './dialog-task-blank.component.html',
  styleUrls: ['./dialog-task-blank.component.css']
})
export class DialogTaskBlankComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
