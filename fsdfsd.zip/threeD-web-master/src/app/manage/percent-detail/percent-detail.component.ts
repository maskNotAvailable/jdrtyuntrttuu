import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-percent-detail',
  templateUrl: './percent-detail.component.html',
  styleUrls: ['./percent-detail.component.css']
})
export class PercentDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
