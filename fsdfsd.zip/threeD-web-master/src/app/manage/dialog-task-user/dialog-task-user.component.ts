import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialog-task-user',
  templateUrl: './dialog-task-user.component.html',
  styleUrls: ['./dialog-task-user.component.css']
})
export class DialogTaskUserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
