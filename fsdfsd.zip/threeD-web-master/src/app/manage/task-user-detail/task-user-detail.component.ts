import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-task-user-detail',
  templateUrl: './task-user-detail.component.html',
  styleUrls: ['./task-user-detail.component.css']
})
export class TaskUserDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
