import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-user-detail',
  templateUrl: './project-user-detail.component.html',
  styleUrls: ['./project-user-detail.component.css']
})
export class ProjectUserDetailComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
