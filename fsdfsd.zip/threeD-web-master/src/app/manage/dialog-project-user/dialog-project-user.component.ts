import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialog-project-user',
  templateUrl: './dialog-project-user.component.html',
  styleUrls: ['./dialog-project-user.component.css']
})
export class DialogProjectUserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
