import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialog-project-blank',
  templateUrl: './dialog-project-blank.component.html',
  styleUrls: ['./dialog-project-blank.component.css']
})
export class DialogProjectBlankComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
