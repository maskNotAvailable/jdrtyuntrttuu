import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-released-product',
  templateUrl: './my-released-product.component.html',
  styleUrls: ['./my-released-product.component.css']
})
export class MyReleasedProductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
