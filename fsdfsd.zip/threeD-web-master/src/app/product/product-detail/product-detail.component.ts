import { Component, OnInit } from '@angular/core';
// import { setFlagsFromString } from 'v8';


@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {
    // var div = document.getElementById('clearfix')?.childNodes[0];
    // console.log(div);
  }
  
 
  

}
