import { Injectable } from '@angular/core';
import { HttpClient ,HttpResponse} from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';
import { interval } from 'rxjs';
import { AnyJson } from '../../../user/login/data-types/common.types';

@Injectable({
  providedIn: 'root'
})
export class StorageService {


  public isLogin1:boolean = true;

  constructor() { }
//登录里用到的部分
     
  

}

